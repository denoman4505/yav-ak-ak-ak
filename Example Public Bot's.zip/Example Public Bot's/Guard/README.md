Merhaba Arkadaşlar Eski Guard Botumu Paylaşmaya Karar Verdim.

Başlıca Özellikleri;

Rol Silindiğinde Kendi Açar Ve Herkese Dağıtır.

Web Tarayacısından Rol Sekmesine Giriş Yapınca Log Atıyor.

Rol Silen Kişi Eğer Bot İle Aynı Yetkiye Sahipse Taç Hesabından Bot Otomatik Şekilde Yasaklıyor.

Web Tarayıcısından Giriş Durumunda Loga Attığı Mesaj;
![image](https://user-images.githubusercontent.com/65469887/148642870-50457895-8ca8-4401-8982-0253f511fe44.png)

Silinen Roller 10 Saniye İçerisinde Listelenecektir Ve Butonlar Yardımıyla Rolleri Dağıtabilceksiniz;
![image](https://user-images.githubusercontent.com/65469887/148643048-2a4ea5d2-4373-430b-8f53-48eeb099cb87.png)


Bot İçerisinde: Rol/Kanal/Sunucu Ayarları Kısaca Guard Botunda Olması Gereken Herşey Var.

Başlıca Birkaç Şeyin Ekran Görüntülerini Paylaştım Altyapıyı 70 Star ve 30 Fork Olduğu Zaman Paylaşacağım Eklememi İstediğiniz Özellikleri Veya Merak Ettiklerinizi Discord Üzerinden Bana Ulaşarak İletebilirsiniz.

https://discord.gg/rate
